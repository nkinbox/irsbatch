<?php $__env->startSection('content'); ?>
<main class="main-content p-4 invisible" data-qp-animate-type="fadeIn" data-qp-animate-delay="600" role="main">
        <div class="row">
        </div>
        <div class="row mb-4">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                  <div class="col-lg-12 pb-5">
                    <?php if(!empty($member)): ?>
                    <?php if(request()->route()->getName() == "ShowApplication"): ?>
                    <h2 style="float:right"><small>applied: </small><?php echo e(date('d-M-y', strtotime($member->applied_on))); ?></h2>
                    <?php else: ?>
                    <h2 style="float:right"><small>Joined: </small><?php echo e(date('d-M-y', strtotime($member->approved_on))); ?></h2>
                    <?php endif; ?>
                    <h2><?php echo e($member->salutation. ' ' .$member->name); ?></h2>
                    <div class="row">
                      <div class="col-md-4">
                        <img src="<?php echo e(asset('photograph/' . $member->photograph)); ?>" style="width:100px">
                      </div>
                      <div class="col-md-8">
                        <table class="table">
                          <tbody>
                            <tr>
                              <td><?php echo e($member->salutation. ' ' .$member->name); ?></td>
                              <td>(<?php echo e($member->designation); ?>)</td>
                              <td><?php echo e($member->hq); ?></td>
                            </tr>
                            <tr>
                              <td>Father/Husband: <?php echo e($member->father_husband_name); ?></td>
                              <td></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td>RailwayId: <?php echo e($member->railway_id); ?></td>
                              <td>VoterId/Aadhar: <?php echo e($member->id_number); ?></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td>PAN: <?php echo e($member->pan_card); ?></td>
                              <td>Mob: <?php echo e($member->mobile_no); ?></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td>PF: <?php echo e($member->pf_no); ?></td>
                              <td></td>
                              <td>DOB: <?php echo e(date('d-M-y',strtotime($member->dob))); ?></td>
                            </tr>
                            <tr>
                              <td></td>
                              <td>DOA: <?php echo e(date('d-M-y',strtotime($member->doa))); ?></td>
                              <td>DOR: <?php echo e(date('d-M-y',strtotime($member->dor))); ?></td>
                            </tr>
                            <tr>
                              <td>Current Address: <?php echo e($member->address); ?></td>
                            </tr>
                            <tr>
                              <td>Permanent Address: <?php echo e($member->permanent_address); ?></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <hr>
                    <h2>Nominee Details</h2>
                    <div>
                      <div class="col-md-4">
                        <img src="<?php echo e(asset('photograph/' . $member->nominee_photograph)); ?>" style="width:100px">
                      </div>
                      <div class="col-md-8">
                        <table class="table">
                          <tbody>
                            <tr>
                              <td><?php echo e($member->salutation . ' ' . $member->nominee_name); ?></td>
                              <td><?php echo e($member->relationship); ?></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td><?php echo e($member->nominee_phone); ?></td>
                              <td></td>
                              <td></td>
                            </tr>
                            <tr>
                              <td><?php echo e($member->nominee_address); ?></td>
                            </tr>

                          </tbody>
                        </table>
                      </div>
                    </div>
  
                    </div>

                    <?php if(count($member->documents) > 0): ?>
                    <hr>
                    <h2>Documents</h2>
                    <div class="row">
                    <?php $__currentLoopData = $member->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-4">
                       <div class="thumbnail">
                         <a href="<?php echo e(asset('documents/' . $doc->file_name)); ?>" target="_blank">
                           <img src="<?php echo e(asset('documents/' . $doc->file_name)); ?>" alt="#" style="width:100%">
                           <div class="caption">
                             <p style="text-align:center"><b><?php echo e($doc->document_name); ?></b></p>
                           </div>
                         </a>
                       </div>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php else: ?>
                    <p>No Documents</p>
                    <?php endif; ?>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>