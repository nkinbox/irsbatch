<?php $__env->startSection('content'); ?>
<div class="container-fluid">
		<div class="row">
			<div class="right-column sisu">
				<div class="row <!-- mx-0 -->">
					<!-- <div class="col-md-7 order-md-2 signin-right-column px-5 bg-dark">
						<a class="signin-logo d-sm-block d-md-none invisible" data-qp-animate-type="fadeInDown" data-qp-animate-delay="0" href="#">
							<img src="assets/img/logo-white.png" width="145" height="32.3" alt="QuillPro">
						</a>
						<h1 class="display-4 invisible" data-qp-animate-type="fadeInDown" data-qp-animate-delay="300">Login In To get Started</h1>
						<p class="lead mb-5 invisible" data-qp-animate-type="fadeInDown" data-qp-animate-delay="750">
							
						</p>
					</div> -->
					<div class="col-md-5 order-md-1 signin-left-column bg-white px-5" style="margin: 0 auto;">
						<a class="signin-logo d-sm-none d-md-block invisible" data-qp-animate-type="fadeIn" data-qp-animate-delay="300" href="#">
							<!--img src="assets/img/logo-dark.png" width="145" height="32.3" alt="QuillPro"--> 
						</a>
						<form class="invisible-children" data-qp-animate-type="fadeIn" data-qp-animate-delay="300" method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo e(csrf_field()); ?>

							<div class="form-group<?php echo e($errors->has('membership_code') ? ' has-error' : ''); ?>">
								<label for="membership_code">Membership Number</label>
								<input type="text" class="form-control" id="membership_code" name="membership_code" placeholder="Membership Code" value="<?php echo e(old('membership_code')); ?>" required>
                                <?php if($errors->has('membership_code')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('membership_code')); ?></strong>
                                </span>
                                <?php endif; ?>
							</div>
							<div class="form-group<?php echo e($errors->has('phone_no') ? ' has-error' : ''); ?>">
								<label for="phone_no">Phone No</label>
								<input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number" value="<?php echo e(old('phone_no')); ?>" >
								<?php if($errors->has('phone_no')): ?>
								<span class="help-block">
									<strong><?php echo e($errors->first('phone_no')); ?></strong>
								</span>
								<?php endif; ?>
                            </div>

							<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
								<label for="password">Enter OTP</label>
                                <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<!--div class="form-check">
								<label class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
									<span class="custom-control-indicator"></span>
									<span class="custom-control-description"> Keep Me Signed In</span>
								</label>
                            </div-->
							<button type="submit" class="btn btn-primary btn-block">
								<i class="batch-icon batch-icon-key"></i>
								Log in
							</button>
							<hr>
							<!--p class="text-center">
								Account Approved? <a href="#">Register here</a>
                            </p-->
                            <!--a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
									Forgot Your Password?
									<?php echo e(route('register')); ?>

                                </a-->
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>