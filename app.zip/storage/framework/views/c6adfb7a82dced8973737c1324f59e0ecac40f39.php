<?php $__env->startSection('content'); ?>
<main class="main-content p-4 invisible" data-qp-animate-type="fadeIn" data-qp-animate-delay="600" role="main">
        <div class="row">
        </div>
        <div class="row mb-4">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                  <div class="col-lg-12 pb-5">
                    <?php if(!empty($member)): ?>
                    <h2><?php echo e($member->first_name . ' ' . $member->last_name); ?></h2>
                    <img src="<?php echo e(asset('public/photograph/' . $member->image_name)); ?>" style="width:100px">
                    <a href="<?php echo e(route('editMemberForm', ['id' => $member->member_id])); ?>">Edit</a>
                    <a href="<?php echo e(route('addECSForm', ['member_id' => $member->member_id])); ?>">Add ECS</a><br>
                    <a href="<?php echo e(route('addBankForm', ['member_id' => $member->member_id])); ?>">Add Bank</a><br>
                    <div><a href="<?php echo e(route('addNomineeForm', ['member_id' => $member->member_id])); ?>">Add Nominee</a></div>
  
                    <?php if(count($nominees) > 0): ?>
                    <?php $__currentLoopData = $nominees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nominee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($nominee); ?></div>
                    <div><a href="<?php echo e(route('editNomineeForm', ['nominee_id' => $nominee->nominee_id])); ?>">Edit</a></div>
                    <div>
                        <form action="<?php echo e(route('deleteNominee')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="nominee_id" value="<?php echo e($nominee->nominee_id); ?>">
                            <input type="hidden" name="_method" value="delete">
                            <button>Delete</button>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p>No Nominee.</p>
                    <?php endif; ?>
                    <?php if(count($profile_docs) > 0): ?>
                    <?php $__currentLoopData = $profile_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($doc->document_name); ?></div>
                    <img src="<?php echo e(asset('storage/documents/' . $doc->file_name)); ?>" style="width: 300px;">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p>No Documents</p>
                    <?php endif; ?>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>