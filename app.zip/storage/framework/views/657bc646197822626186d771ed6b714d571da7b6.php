<?php $__env->startSection('content'); ?>
<main class="main-content p-4 invisible" data-qp-animate-type="fadeIn" data-qp-animate-delay="600" role="main">
<div class="row mb-4">
<div class="col-md-12">
<div class="card">
<div class="card-body">
    <div class="row">
        <div class="col-lg-12 pb-5">
            <h2>Admission Approval</h2>
            <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(count($members) > 0): ?>
            <table class="table table-responsive">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name Of Member</th>
                        <th>Father/Husband Name</th>
                        <th>Designation</th>
                        <th>Hq</th>
                        <th>Railway Id</th>
                        <th>Applied On</th>
                        <th>Cheque No</th>
                        <th>MemberShip NO</th>
                        <th>ADM Incharge</th>
                        <th>Cashier </th>
                        <th>VP</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php $i++; echo $i;?></th>
                        <td><?php echo e($member->name); ?></td>
                        <td><?php echo e($member->father_husband_name); ?></td>
                        <td><?php echo e($member->designation); ?></td>
                        <td><?php echo e($member->hq); ?></td>
                        <td><?php echo e($member->railway_id); ?></td>
                        <td><?php echo e($member->applied_on); ?></td>
                        <td>Cheque No</td>
                        <td><code><?php echo e($membership_code); ?></code></td>
                        <td>
                            <?php if($member->adm_incharge == null): ?>
                            <form action="<?php echo e(route('SignatureUpload')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                                <input type="hidden" name="sign_of" value="adm_incharge">
                                <input type="file" name="signature" required>
                                <button type="submit">Sign</button>
                            </form>
                            <?php else: ?>
                            <img src="<?php echo e(asset('signature/'.$member->adm_incharge)); ?>" style="width:100px">
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($member->cashier == null): ?>
                            <form action="<?php echo e(route('SignatureUpload')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                                <input type="hidden" name="sign_of" value="cashier">
                                <input type="file" name="signature" required>
                                <button type="submit">Sign</button>
                            </form>
                            <?php else: ?>
                            <img src="<?php echo e(asset('signature/'.$member->cashier)); ?>" style="width:100px">
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($member->vice_president == null): ?>
                            <form action="<?php echo e(route('SignatureUpload')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                                <input type="hidden" name="sign_of" value="vice_president">
                                <input type="file" name="signature" required>
                                <button type="submit">Sign</button>
                            </form>
                            <?php else: ?>
                            <img src="<?php echo e(asset('signature/'.$member->vice_president)); ?>" style="width:100px">
                            <?php endif; ?>
                        </td>
                        <td>
                            <form id="accept<?php echo e($member->id); ?>" action="<?php echo e(route('ApplicationStatus')); ?>" method="post" style="display:none">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                                <input type="hidden" name="status" value="accepted">
                            </form>
                            <form id="reject<?php echo e($member->id); ?>" action="<?php echo e(route('ApplicationStatus')); ?>" method="post" style="display:none">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="id" value="<?php echo e($member->id); ?>">
                                    <input type="hidden" name="status" value="rejected">
                                </form>
                            <a href="<?php echo e(route('ShowApplication', $member->id)); ?>" target="_blank">View</a>/
                            <a href="#" onclick="document.getElementById('accept<?php echo e($member->id); ?>').submit();">Approve</a>/
                            <a href="#" onclick="document.getElementById('reject<?php echo e($member->id); ?>').submit();">Reject</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <div>No Pending Applications</div>
            <?php endif; ?>
        </div>	
    </div>
</div>
</div>
</div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>